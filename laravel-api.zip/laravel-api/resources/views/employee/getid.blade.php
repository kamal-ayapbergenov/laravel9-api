<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 29.07.2022
 * Time: 17:44
 */
?>
<div class="container">
    <div class="row">
        {{$gets->name}}
        <br>
        {{$gets->email}}
        <br>
        {{$gets->salary}}
        <hr>
    </div>
</div>

