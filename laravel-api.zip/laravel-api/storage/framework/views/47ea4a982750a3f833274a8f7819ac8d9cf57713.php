<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 29.07.2022
 * Time: 17:37
 */
?>

<?php $__currentLoopData = $get; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('/employee/'.$gets->id)); ?>"><?php echo e($gets->name); ?></a>
    <br>
    <?php echo e($gets->email); ?>

    <br>
    <?php echo e($gets->salary); ?>

    <hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH F:\Project\Server-B\2022\OpenServer\domains\laravel-api\resources\views/employee/get.blade.php ENDPATH**/ ?>