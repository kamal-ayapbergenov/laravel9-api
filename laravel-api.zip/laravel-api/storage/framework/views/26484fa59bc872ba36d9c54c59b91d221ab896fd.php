<?php
/**
 * Created by PhpStorm.
 * User: User
 * Date: 29.07.2022
 * Time: 17:44
 */
?>
<div class="container">
    <div class="row">
        <a href="<?php echo e(url('/employee/'.$gets->id)); ?>"><?php echo e($gets->name); ?></a>
        <br>
        <?php echo e($gets->email); ?>

        <br>
        <?php echo e($gets->salary); ?>

        <hr>
    </div>
</div>

<?php /**PATH F:\Project\Server-B\2022\OpenServer\domains\laravel-api\resources\views/employee/getid.blade.php ENDPATH**/ ?>